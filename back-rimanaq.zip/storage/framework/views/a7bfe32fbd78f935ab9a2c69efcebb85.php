
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title><?php echo $__env->yieldContent('title', 'Rimanaq'); ?></title>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">


<?php echo $__env->yieldContent('head'); ?>


<?php echo $__env->yieldContent('styles'); ?>


<link rel="icon" href="/favicon.ico" type="image/x-icon"><?php /**PATH C:\xampp\htdocs\back-rimanaq\resources\views/components/head.blade.php ENDPATH**/ ?>